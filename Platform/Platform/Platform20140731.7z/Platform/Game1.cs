using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace Platform
{
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        AnimatedSprite sprite;
        
        
        SpriteFont font;

        Texture2D TitleScreen;
        Texture2D GameScreen;

        StaticSprite background;

        List<List<StaticSprite>> levels_BuildingBlocks = new List<List<StaticSprite>>();
        List<List<EnemySprite>> levels_Enemies = new List<List<EnemySprite>>();

        
        List<Rectangle> nextLevelAreas = new List<Rectangle>();
        List<Vector2> startPositions = new List<Vector2>();


        string[] fileNamesOfLevels_BuildingBlocks;
        string[] fileNamesOfLevels_Enemies;

        int numberOfLevels;

        string result;
        int currentLevel;
        
        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }

        protected override void Initialize()
        {
            base.Initialize();
        }

        protected override void LoadContent()
        {
            spriteBatch = new SpriteBatch(GraphicsDevice);
            background = new StaticSprite(Content.Load<Texture2D>("air-20529_1280"), 800, 480);
            background.Origin = new Vector2(400, 240);
            background.Position = new Vector2(0, 0);
            background.SourceRect = new Rectangle(0, 0, 1600, 960);
            
            
            
            // l�s in objekt f�r varje bana fr�n textfil (numrerade blockobjekt-filerna som ligger i content, motsvarande fiende-filer
            // ligger i underkatalogen "Enemies")
            string directory = Directory.GetCurrentDirectory();
            string contentDirectory = @"Content";
            result = Path.Combine(directory, contentDirectory);
            fileNamesOfLevels_BuildingBlocks = Directory.GetFiles(result, "*.txt");

            Array.Sort(fileNamesOfLevels_BuildingBlocks);
            numberOfLevels = fileNamesOfLevels_BuildingBlocks.Length;
            
            foreach (string s in fileNamesOfLevels_BuildingBlocks)
            {

                string file = @"Content\" + Path.GetFileName(s);
                string[] staticSpriteValues;
                string line;

                List<StaticSprite> sprites = new List<StaticSprite>();

                using (StreamReader r = new StreamReader(file))
                {
                    while ((line = r.ReadLine()) != null)
                    {
                        staticSpriteValues = line.Split(',');

                        if (staticSpriteValues.Length == 13)
                        {
                            // Omr�det d�r man flyttas till n�sta bana ligger p� f�rsta raden (inte alltid) i varje blockobjekt-fil
                            // och dessa v�rden l�ggs in i en lista av rektanglar som anger respektive omr�de
                            Rectangle nextLevelArea = new Rectangle(int.Parse(staticSpriteValues[7]),
                            int.Parse(staticSpriteValues[8]),
                            int.Parse(staticSpriteValues[9]),
                            int.Parse(staticSpriteValues[10]));
                            nextLevelAreas.Add(nextLevelArea);
                            
                            // Startpositionen f�r spelkarakt�ren p� varje bana ligger ocks� p� f�rsta raden
                            Vector2 startPosition = new Vector2(int.Parse(staticSpriteValues[11]),
                                int.Parse(staticSpriteValues[12]));
                            startPositions.Add(startPosition);
                        }

                        // Alla andra rader i block-filerna inneh�ller bara 7 v�rden (varje blockobjekts v�rden)
                        StaticSprite sp = new StaticSprite(Content.Load<Texture2D>("brick"), int.Parse(staticSpriteValues[2]), int.Parse(staticSpriteValues[3]));
                        sp.SourceRect = new Rectangle(int.Parse(staticSpriteValues[0]), int.Parse(staticSpriteValues[1]), int.Parse(staticSpriteValues[2]), int.Parse(staticSpriteValues[3]));
                        sp.Origin = new Vector2(int.Parse(staticSpriteValues[2]) / 2, int.Parse(staticSpriteValues[3]) / 2);
                        sp.Position = new Vector2(int.Parse(staticSpriteValues[4]), int.Parse(staticSpriteValues[5]));
                        sp.Moving = int.Parse(staticSpriteValues[6]);
                        sp.Counter = 2;

                        // OBS!!!
                        // De rader som inneh�ller v�rden f�r block-objekt som kan r�ra p� sig, inneh�ller ocks� 13 v�rden!
                        // D�rf�r ligger det "dummy"-v�rden efter de faktiska v�rderna bara f�r att �ndra p� l�ngden p� raden.
                        // Det blir problem om man inte g�r det, d� hittar den mer �n en rad som inneh�ller 13 v�rden och 
                        // �kar antalet objekt i listorna "nextLevelAreas" och "startPositions". 
                        // Om block-objektet kan r�ra p� sig inneh�ller raden 13 v�rden, men "dummy-v�rden" ligger i slutet f�r att
                        // s�rskilja den fr�n den rad som anger karakt�rens startposition och omr�de f�r att komma till n�sta bana (se ovan).
                        if (staticSpriteValues.Length > 7 && int.Parse(staticSpriteValues[6]) == 1)
                        {
                            sp.XSpeed = int.Parse(staticSpriteValues[7]);
                            sp.YSpeed = int.Parse(staticSpriteValues[8]);
                            sp.MinX = int.Parse(staticSpriteValues[9]);
                            sp.MaxX = int.Parse(staticSpriteValues[10]);
                            sp.MinY = int.Parse(staticSpriteValues[11]);
                            sp.MaxY = int.Parse(staticSpriteValues[12]);
                        }

                        
                        sprites.Add(sp);
                    }
                }

                levels_BuildingBlocks.Add(sprites);
            }            
            
            // l�s in fiender f�r varje bana fr�n fil (numrerade filer som ligger i underkatalogen "Enemies")
            directory = Directory.GetCurrentDirectory();
            contentDirectory = @"Content\Enemies";
            result = Path.Combine(directory, contentDirectory);
            fileNamesOfLevels_Enemies = Directory.GetFiles(result, "*.txt");

            Array.Sort(fileNamesOfLevels_Enemies);
            
            foreach (string s in fileNamesOfLevels_Enemies)
            {

                string file = @"Content" + @"\Enemies\" + Path.GetFileName(s);
                string[] enemySpriteValues;
                string line;

                List<EnemySprite> enemies = new List<EnemySprite>();

                using (StreamReader r = new StreamReader(file))
                {
                    while ((line = r.ReadLine()) != null)
                    {
                        enemySpriteValues = line.Split(',');
                        EnemySprite en = new EnemySprite(Content.Load<Texture2D>("sprite_3"), int.Parse(enemySpriteValues[0]), int.Parse(enemySpriteValues[1]), int.Parse(enemySpriteValues[2]));
                        en.SourceRect = new Rectangle((int.Parse(enemySpriteValues[0]) * int.Parse(enemySpriteValues[1])), 0, int.Parse(enemySpriteValues[1]), int.Parse(enemySpriteValues[2]));
                        en.Origin = new Vector2(en.SourceRect.Width / 2, en.SourceRect.Height / 2);
                        en.XSpeed = int.Parse(enemySpriteValues[3]);
                        en.YSpeed = int.Parse(enemySpriteValues[4]);
                        en.Position = new Vector2(int.Parse(enemySpriteValues[5]), int.Parse(enemySpriteValues[6]));
                        en.MinX = int.Parse(enemySpriteValues[7]);
                        en.MaxX = int.Parse(enemySpriteValues[8]);
                        en.MinY = int.Parse(enemySpriteValues[9]);
                        en.MaxY = int.Parse(enemySpriteValues[10]);
                        enemies.Add(en);
                        //0,40,46,2,1,40,365,40,100,300,365
                    }
                }

                levels_Enemies.Add(enemies);

            }

            
            
            sprite = new AnimatedSprite(Content.Load<Texture2D>("sprite_2"), 0, 40, 46);
            //sprite.Position = startPositions[1];

            
            font = Content.Load<SpriteFont>("font2");

            currentLevel = 3;
            sprite.Position = startPositions[3];
        }

        protected override void UnloadContent()
        {
        }

        protected override void Update(GameTime gameTime)
        {

            if (sprite.State != 4) // Kontroll s� att spelkarakt�ren inte har d�tt
            {
                // Kollisionshantering mellan banans blockobjekt och spelkarakt�rer utifr�n karakt�rens v�nstra sida
                foreach (StaticSprite spr in levels_BuildingBlocks[currentLevel]) 
                {
                    if (sprite.LeftLine.Intersects(spr.BoundingBox))
                    {
                        sprite.CollisionLeft = true;
                        break;
                    }

                    sprite.CollisionLeft = false;

                }

                // Kollisionshantering mellan blockobjekt och spelkarakt�r utifr�n karakt�rens h�gra sida
                foreach (StaticSprite spr in levels_BuildingBlocks[currentLevel])
                {
                    if (sprite.RightLine.Intersects(spr.BoundingBox))
                    {
                        sprite.CollisionRight = true;
                        break;
                    }

                    sprite.CollisionRight = false;

                }

                // Kollisionshantering mellan blockobjekt och spelkarakt�r utifr�n karakt�rens ovansida
                foreach (StaticSprite spr in levels_BuildingBlocks[currentLevel])
                {
                    if (sprite.UpLine.Intersects(spr.BoundingBox))
                    {
                        sprite.CollisionUp = true;
                        break;
                    }

                    sprite.CollisionUp = false;
                }

                // Kollisionshantering mellan blockobjekt och spelkarakt�r utifr�n karakt�rens undersida
                foreach (StaticSprite spr in levels_BuildingBlocks[currentLevel])
                {
                    if (sprite.DownLine.Intersects(spr.BoundingBox))
                    {
                        sprite.CollisionDown = true;
                        break;
                    }

                    sprite.CollisionDown = false;
                }
            }

            // Detta �r motsvarande kollisionshantering mellan varje fiendefigur och blockobjekten p� banan
            foreach (EnemySprite ene in levels_Enemies[currentLevel])
            {
                // Kollisionshantering mellan aktuell fiende i loopen och varje blockobjekt utifr�n fiendes v�nstra sida
                foreach (StaticSprite spr in levels_BuildingBlocks[currentLevel])
                {
                    if (ene.LeftLine.Intersects(spr.BoundingBox))
                    {
                        ene.CollisionLeft = true;
                        break;
                    }

                    ene.CollisionLeft = false;
                }

                // Kollisionshantering mellan aktuell fiende i loopen och varje blockobjekt utifr�n fiendes h�gra sida
                foreach (StaticSprite spr in levels_BuildingBlocks[currentLevel])
                {
                    if (ene.RightLine.Intersects(spr.BoundingBox))
                    {
                        ene.CollisionRight = true;
                        break;
                    }

                    ene.CollisionRight = false;
                }
                
                // Kollisionshantering mellan aktuell fiende i loopen och varje blockobjekt utifr�n fiendes ovansida
                foreach (StaticSprite spr in levels_BuildingBlocks[currentLevel])
                {
                    if (ene.UpLine.Intersects(spr.BoundingBox))
                    {
                        ene.CollisionUp = true;
                        break;
                    }

                    ene.CollisionUp = false;
                }

                // Kollisionshantering mellan aktuell fiende i loopen och varje blockobjekt utifr�n fiendes undersida
                foreach (StaticSprite spr in levels_BuildingBlocks[currentLevel])
                {
                    if (ene.DownLine.Intersects(spr.BoundingBox))
                    {
                        ene.CollisionDown = true;
                        break;
                    }

                    ene.CollisionDown = false;
                }

                // Kollisionshantering mellan aktuell fiende i loopen och spelkarakt�ren
                if (ene.BoundingBox.Intersects(sprite.BoundingBox))
                {
                    // Fiende kan bara d�das om spelkarakt�ren hoppar p� den ovanifr�n
                    if ((sprite.DownLine.Intersects(ene.BoundingBox)) && sprite.State != 4)
                    {
                        ene.Killed = true;
                        sprite.JumpSpeed = -14;
                        sprite.State = 2;
                    }

                    // Vidr�r spelkarakt�ren fienden fr�n n�got annat h�ll d�r spelkarakt�ren
                    else
                    {
                        sprite.State = 4;
                    }
                }

                ene.HandleSpriteMovement(gameTime);
            }

            // Ett blockobjekt har f�rm�ga att r�ra p� sig. 
            // Detta f�r att spelkarakt�ren ska kunna ta sig �ver str�ckor som den inte kan hoppa mellan.
            // Position 7 p� varje rad i blockobjekt-filen avg�r detta f�r varje blockobjekt.
            // 0 = ej r�rlig, 1 = r�rlig
            foreach (StaticSprite spr in levels_BuildingBlocks[currentLevel])
            {
                if (spr.Moving == 1)
                {
                    spr.Position = new Vector2(spr.Position.X + spr.XSpeed, spr.Position.Y + spr.YSpeed);

                    if (spr.Position.X > spr.MaxX)
                    {
                        spr.XSpeed = spr.XSpeed - (spr.XSpeed * 2);
                    }

                    if (spr.Position.X < spr.MinX)
                    {
                        spr.XSpeed = spr.XSpeed - (spr.XSpeed * 2);
                    }

                    if (spr.Position.Y > spr.MaxY)
                    {
                        spr.YSpeed = spr.YSpeed - (spr.YSpeed * 2);
                    }

                    if (spr.Position.Y < spr.MinY)
                    {
                        spr.YSpeed = spr.YSpeed - (spr.YSpeed * 2);
                    }


                    if ((sprite.DownLine.Intersects(spr.BoundingBox)) && !sprite.CollisionLeft && !sprite.CollisionRight)
                    {
                       
                        
                        if (spr.YSpeed > 0)
                        {
                                sprite.Position = new Vector2(spr.Position.X, (spr.Position.Y - spr.SpriteHeight) + spr.YSpeed);
                        }

                        else
                        {
                            sprite.Position = new Vector2(spr.Position.X, spr.Position.Y - spr.SpriteHeight - spr.YSpeed);
                        }

                    }

                    if (sprite.RightLine.Intersects(spr.BoundingBox))
                    {
                        sprite.Position = new Vector2(spr.Position.X - sprite.SpriteWidth, sprite.Position.Y);
                    }

                    if (sprite.LeftLine.Intersects(spr.BoundingBox))
                    {
                        sprite.Position = new Vector2(spr.Position.X + sprite.SpriteWidth, sprite.Position.Y);
                    }

                }

                
            }

           

            if (sprite.BoundingBox.Intersects(nextLevelAreas[currentLevel]))
            {
                if (currentLevel < numberOfLevels)
                {
                    currentLevel++;
                    sprite.Position = startPositions[currentLevel];
                }
            }

            
            sprite.HandleSpriteMovement(gameTime);
            //enemySprite.HandleSpriteMovement(gameTime);

            base.Update(gameTime);
        
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.LightBlue);

            spriteBatch.Begin();
            spriteBatch.Draw(background.Texture, background.Position, background.SourceRect, Color.White, 0f, background.Origin, 1.0f, SpriteEffects.None, 0);
            
            spriteBatch.Draw(sprite.Texture, sprite.Position, sprite.SourceRect, Color.White, 0f, sprite.Origin, 1.0f, SpriteEffects.None, 0);


            
            foreach (StaticSprite spr in levels_BuildingBlocks[currentLevel])
            {
                spriteBatch.Draw(spr.Texture, spr.Position, spr.SourceRect, Color.White, 0f, spr.Origin, 1.0f, SpriteEffects.None, 0);
            }

            foreach (EnemySprite enemySprite in levels_Enemies[currentLevel])
            {
                spriteBatch.Draw(enemySprite.Texture, enemySprite.Position, enemySprite.SourceRect, Color.White, 0f, enemySprite.Origin, 1.0f, SpriteEffects.None, 0);
            }

            /*string pos = "  Left:" + sprite.CollisionLeft.ToString() +
                "  Right:" + sprite.CollisionRight.ToString() +
                "  Up:" + sprite.CollisionUp.ToString() +
                "  Down:" + sprite.CollisionDown.ToString();*/
            //string pos = resultb[0];
            
            //string pos = cleft.ToString() + cright.ToString() + cup.ToString() + cdown.ToString();
            //string pos = numberOfLevels.ToString();
            //string pos = levels_Enemies[0][0].Position.X.ToString();
            string pos = startPositions[0].ToString() + startPositions[1].ToString() + startPositions[2].ToString();
            spriteBatch.DrawString(font, pos, new Vector2(0, 0), Color.White);
            
            spriteBatch.End();
            base.Draw(gameTime);

        }
    }
}
